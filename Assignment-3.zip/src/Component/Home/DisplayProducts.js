import React from 'react';

const Display = (props) => {

    const renderData = ({productdata}) => {
        if(productdata){
            return productdata.map((item) => {
                return(
                    <tr key={item.id}>
                        <td>{item.id}</td>
                        <td>{item.product_name}</td>
                        <td>{item.quantity}</td>
                        <td>{item.price}</td>
                    </tr>
                )
            })
        }
    }

    return(
        <div className="container">
            <center><h3>Products</h3></center>
            <table className="table">
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Products Name</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        
                    </tr>
                </thead>
                <tbody>
                    {renderData(props)}
                </tbody>
            </table>
        </div>

    )

}

export default Display;