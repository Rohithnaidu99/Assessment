import React from 'react'




const ViewProducts = (props) => {

    const renderData = ({viewData}) => {
        if(viewData){
            return viewData.map((item) => {
                return(
                <tr key={item.id}>
                    <td>{item.id}</td>
                    <td>{item.product_name}</td>
                    <td>{item.quantity}</td>
                    <td>{item.price}</td>
                </tr>
                )
            })
        }
    }

 
    
 
    return(
        <div style={{ position: 'absolute', top: '90px', left: '10px', right: '10px', bottom: '10px' }}>
            
            <table class="table table-striped">
                <thead>
                    <tr>
                    <th>ID</th>
                    <th>Product Name</th>
                    <th>Quantity</th>
                    <th>Price</th>
                    </tr>
                </thead>
                <tbody>
                 
                    
                    {renderData(props)}
                    
                </tbody>
            </table>
            
           
        </div>
        

    )
 }
 
 export default ViewProducts;