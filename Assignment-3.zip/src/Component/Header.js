import React from 'react';

import './Header.css';


const Header = () => {


    return(
        <>
            <header>
                <div id="brand">
                    Products Lists &nbsp;&nbsp; 
                   
                </div>
            </header>
        </>
    )
}

export default Header;