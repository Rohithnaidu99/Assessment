import React from 'react'
import JsonData from './data.json'
 function JsonDataDisplay(){
    const renderData=JsonData.map(
        (info)=>{
            return(
                <tr>
                    <td>{info.id}</td>
                    <td>{info.product_name}</td>
                    <td>{info.quantity}</td>
                    <td>{info.price}</td>
                </tr>
            )
        }
    )
    
 
    return(
        <div style={{ position: 'absolute', top: '90px', left: '10px', right: '10px', bottom: '10px' }}>
            
            <table class="table table-striped">
                <thead>
                    <tr>
                    <th>ID</th>
                    <th>Product Name</th>
                    <th>Quantity</th>
                    <th>Price</th>
                    </tr>
                </thead>
                <tbody>
                 
                    
                    {renderData}
                    
                </tbody>
            </table>
            
           
        </div>
        

    )
 }
 
 export default JsonDataDisplay;